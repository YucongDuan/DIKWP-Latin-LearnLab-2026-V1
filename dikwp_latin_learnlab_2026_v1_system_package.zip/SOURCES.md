# Sources and Reference Principles

- American Classical League / Society for Classical Studies, Standards for Classical Language Learning.
- ACTFL World-Readiness Standards for Learning Languages, Five Cs: Communication, Cultures, Connections, Comparisons, Communities.
- College Board AP Latin course and exam materials: reading and comprehending Latin poetry and prose, style/context, analysis, vocabulary, grammar, syntax, and scansion.
- Dickinson College Commentaries Core Vocabulary: a core list of common Latin words.
- Perseus Digital Library / Scaife Viewer: digital classical texts and morphology support.
- DIKWP TransitTrustGraph OS reference architecture: Evidence Ledger, Action Ticket, human review, static boundary audit.

All external language standards and digital resources must be rechecked by teachers before formal curriculum use.
