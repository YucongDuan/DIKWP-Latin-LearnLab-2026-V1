# 30-Day Pilot Plan

## Week 1
Learner profile, Purpose Contract, pronunciation baseline, first/second declension, present-tense verbs.

## Week 2
Noun-adjective agreement, case functions, short sentence parsing, vocabulary retrieval.

## Week 3
Third declension, common clauses, translation three-draft method, AI Use Log and Error Ledger.

## Week 4
Short adapted reading, closed-book parse, oral defense, Learning Passport export.

## Acceptance criteria
- At least 10 morphology evidence records.
- At least 5 syntax parse records.
- At least 1 three-draft translation.
- At least 1 AI Use Log.
- Learner can close AI and explain key forms.
