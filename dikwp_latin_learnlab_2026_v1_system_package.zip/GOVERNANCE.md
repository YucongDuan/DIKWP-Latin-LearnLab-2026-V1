# Governance and Academic Integrity

## Prohibited uses
- AI-generated homework submitted as human work.
- Fabricated Latin texts, dictionary entries, commentaries, citations, or teacher feedback.
- Automated final grading, certification, admissions, or scholarship decisions.
- Hidden learner profiling or surveillance.

## Required safeguards
- AI Use Log for every material AI interaction.
- Closed-book reproduction for core morphology and syntax.
- Evidence Ledger for translations, parses, readings, and commentaries.
- Human teacher or peer review for high-stakes coursework.
- Residuals and uncertainty must be visible.
