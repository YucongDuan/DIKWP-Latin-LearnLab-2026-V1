#!/usr/bin/env python3
from __future__ import annotations
import argparse,json
from pathlib import Path
from datetime import datetime,timezone

def main():
    p=argparse.ArgumentParser();p.add_argument('learner',type=Path);p.add_argument('--out',type=Path,default=Path('outputs'));args=p.parse_args()
    learner=json.loads(args.learner.read_text(encoding='utf-8'))
    h=float(learner.get('hours_per_week',5))
    if h<4: mix={'pronunciation':15,'morphology':30,'syntax':20,'vocab':20,'reading':8,'translation':5,'culture':2}
    elif h<8: mix={'pronunciation':10,'morphology':25,'syntax':22,'vocab':18,'reading':15,'translation':7,'culture':3}
    else: mix={'pronunciation':6,'morphology':20,'syntax':20,'vocab':16,'reading':20,'translation':14,'culture':4}
    passport={'version':'DIKWP Latin LearnLab 2026 V1 CLI','generated_at':datetime.now(timezone.utc).isoformat(),'learner':learner,'weekly_mix_percent':mix,'required_controls':['Evidence Ledger','Error Ledger','AI Use Log','closed-book reproduction','human teacher review'],'boundaries':{'official_certification':False,'auto_grading':False,'ghostwriting':False,'teacher_review_required':True}}
    args.out.mkdir(parents=True,exist_ok=True);target=args.out/(learner.get('learner_id','learner')+'_latin_passport.json');target.write_text(json.dumps(passport,ensure_ascii=False,indent=2),encoding='utf-8')
    print('DIKWP Latin LearnLab 2026 V1');print('Output:',target)
if __name__=='__main__':main()
