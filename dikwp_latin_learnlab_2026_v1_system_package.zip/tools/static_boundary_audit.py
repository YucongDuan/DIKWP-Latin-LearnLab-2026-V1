#!/usr/bin/env python3
from pathlib import Path
import json,re
ROOT=Path(__file__).resolve().parents[1]
PATTERNS=[(r'\brequests\.', 'network'),(r'\burllib\.request','url'),(r'\bsocket\.', 'socket'),(r'\beval\(','eval'),(r'\bexec\(','exec'),(r'localStorage','browser storage')]
EXCLUDE={'static_boundary_audit.py','static_boundary_audit_report.json'}
findings=[]
for p in ROOT.rglob('*'):
    if not p.is_file() or p.name in EXCLUDE or p.suffix.lower() not in {'.py','.html','.js','.json'}: continue
    txt=p.read_text(encoding='utf-8',errors='ignore')
    for pat,meaning in PATTERNS:
        if re.search(pat,txt,re.I): findings.append({'file':str(p.relative_to(ROOT)),'meaning':meaning})
res={'package':'DIKWP Latin LearnLab 2026 V1','network_or_hidden_storage_detected':bool(findings),'findings':findings,'note':'No model API, LMS writeback, exam system connection, or credential storage adapters are included.'}
(ROOT/'static_boundary_audit_report.json').write_text(json.dumps(res,ensure_ascii=False,indent=2),encoding='utf-8')
print(json.dumps(res,ensure_ascii=False,indent=2))
